alter table customer add lmthu float default 0;
alter table customer add lmthl float default 0;
alter table customer add lmtht float default 0;
alter table customer add lmtwu float default 0;
alter table customer add lmtwl float default 0;
alter table customer add lmtwt float default 0;
alter table customer add lmrnu float default 0;
alter table customer add lmrnl float default 0;
